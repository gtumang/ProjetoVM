import cv2 as cv
import time

cap = cv.VideoCapture(cv.CAP_DSHOW)

i=0
while i<100:
  _, img_raw = cap.read()
  img = img_raw.copy()[50:-170, 50:-50]
  cv.imwrite(f"topeira_{i}.png",img)
  i+=1
  time.sleep(1)